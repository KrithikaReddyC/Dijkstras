from pyspark import SparkConf, SparkContext

     def dijkstra_spark(file_path, start_node, output_file):
         try:
             # Initialize Spark context
             conf = SparkConf().setAppName("DijkstraSpark").setMaster("local[*]")
             sc = SparkContext(conf=conf)

             # Read the graph file
             lines = sc.textFile(file_path)
             header = lines.first()
             num_nodes = int(header.split(" ")[0])

             # Parse edges into (src, (dst, weight))
             edges = lines.filter(lambda line: line != header).map(
                 lambda line: tuple(map(int, line.strip().split()))
             ).map(lambda x: (x[0], (x[1], x[2]))).groupByKey().mapValues(list).cache()

             # Create vertices (node, (distance, path))
             vertices = sc.parallelize(
                 [(node, (0 if node == start_node else float('inf'), [start_node] if node == start_node else [])) 
                  for node in range(num_nodes)]
             )

             # Iterative Dijkstra's algorithm
             distances = vertices
             max_iterations = num_nodes  # Max iterations can be number of nodes
             for _ in range(max_iterations):
                 # Broadcast current distances and paths
                 current_distances = dict(distances.collect())
                 broadcast_distances = sc.broadcast(current_distances)

                 # Compute updates: (dst, (new_dist, new_path))
                 updates = edges.flatMap(lambda x: [
                     (dst, (broadcast_distances.value[x[0]][0] + weight, broadcast_distances.value[x[0]][1] + [dst]))
                     for dst, weight in x[1]
                     if broadcast_distances.value[x[0]][0] != float('inf')
                 ])

                 # Combine updates with current distances, keeping the minimum distance and corresponding path
                 combined = distances.union(updates).reduceByKey(
                     lambda a, b: a if a[0] <= b[0] else b
                 )

                 # Check for convergence
                 if combined.collect() == distances.collect():
                     break

                 distances = combined

             # Collect results
             result = distances.collect()

             # Write results to file
             with open(output_file, "w") as f:
                 print("Writing to file:", output_file)  # Debug print
                 for node, (dist, path) in sorted(result, key=lambda x: x[0]):
                     if dist == float('inf'):
                         f.write(f"Node {node}: Distance INF, Path None\n")
                     else:
                         path_str = "->".join(map(str, path))
                         f.write(f"Node {node}: Distance {dist}, Path {path_str}\n")

             print("Script completed successfully. Output written to", output_file)

         except Exception as e:
             print("An error occurred:", str(e))
             raise
         finally:
             sc.stop()

     if __name__ == "__main__":
         dijkstra_spark("/home/azureuser/weighted_graph.txt", 0, "shortest_paths.txt")